<?php

    require_once('include/sign_in_inc.php');
    require_once('work/db.php');
    require_once('work/function.php');

    include 'header.php';

?>



<div class="container ">
        <header class="bg-dark py-5">
            <div class="container px-4 px-lg-5 my-5">
                <div class="text-center text-white">
                    <h1 class="display-4 fw-bolder">Shop in style</h1>
                    <p class="lead fw-normal text-white-50 mb-0">With this shop hompeage template</p>
                </div>
            </div>
        </header>
    </div>


     <!-- Section-->
     <section class="py-5">
        <div class="container px-4 px-lg-5 mt-5">
            <div class="row gx-4 gx-lg-5 row-cols-2 row-cols-md-3 row-cols-xl-4 justify-content-center">
                <?php
                $result = getData($con,'product');
                while($row=mysqli_fetch_assoc($result)){
                    date_default_timezone_set('Asia/Dhaka');
                    $currentTime = date('Y-m-d H:i:s');
                    if($currentTime<$row['end_time'] && $currentTime>=$row['start_time']){?>
                        <div class="col mb-5">
                            <div class="card h-100">
                                <!-- Product image-->
                                <img class="card-img-top" src="image/<?= $row['product_img'] ?>" alt="..." />
                                <!-- Product details-->
                                <div class="card-body p-4">
                                    <div class="text-center">
                                        <!-- Product name-->
                                        <h4 class="fw-bolder"><?= $row['product_name'] ?></h4>
                                        
                                        <!-- Product price-->
                                        <p><?= $row['product_price'] ?> BDT</p>
                                        <h5 style="background-color: red; color:aqua;padding:1px">Till <?= $row['end_time']?></h5>
                                    </div>
                                </div>
                                <!-- Product actions-->
                                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                                    <div class="text-center">
                                        <form method="post" action="include/auction.php?action=add&id=<?= $row['id'] ?>" enctype="multipart/form-data">
                                        <input type="hidden" class="Id" name="product_id" value="<?= $row['id'] ?>">
                                        <input type="submit" value="View" class="btn btn-small btn-info" name="view_product">
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php }
                 } ?>
                
            </div>
        </div>
    </section>

<?php
    include 'footer.php';
?>