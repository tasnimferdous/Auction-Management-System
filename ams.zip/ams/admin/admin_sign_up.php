
<div class="container">

    <div class="row align-items-center">
        <div class="col mt-5">
            <br><br>
            <h3>New Admin Registration</h3>
            <div class="admin-signup">
                <form action="sign_up_call.php" method="POST">
                    <label>Enter Name:</label><br>
                    <input type="text" class="form-control" name="admin_name" required>
                    <label>Enter Email:</label><br>
                    <input type="email" class="form-control" name="admin_email" required>
                    <label>Enter Password:</label><br>
                    <input type="password" class="form-control" name="admin_password" required>
                    <label>Confirm Password:</label><br>
                    <input type="password" class="form-control" name="admin_password_confirm" required>
                    <br>

                    <input type="submit" value="Sign Up" class="btn btn-small btn-info" name="admin_signup"><br>
                </form>
            </div>

        </div>

    </div>

</div>

