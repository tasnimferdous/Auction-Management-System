<?php

require_once('../work/function.php');

if(isset($_POST['admin_signup'])){
    
    require_once('../work/db.php');
    $user_name = $_POST['admin_name'];
    $user_email = $_POST['admin_email'];
    $user_password = md5($_POST['admin_password']);
    $user_password_confirm = md5($_POST['admin_password_confirm']);
    $user_role = "admin";
    
    if($user_password == $user_password_confirm){
        $sql="SELECT * FROM user WHERE user_email='$user_email'";
        $result=mysqli_query($con,$sql);
        if(mysqli_num_rows($result)>0){
            echo"<script>alert ('Email already exists');
            window.location.href='dashboard.php';
            </script>";
        }
        else{
            signUpUser($con, $user_name, $user_email, $user_phone, $user_password, $user_role);
        }
    }else{
        echo"<script>alert ('Password doesn\'t match');
        window.location.href='dashboard.php';
        </script>";
    }
}



?>