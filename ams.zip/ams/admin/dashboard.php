<?php
    session_start();
    include 'header.php';
    require_once('../work/function.php');
    require_once('../work/db.php');

?>



<div class="container">
    <div class="row align-items-center profile">
        <div class="image col-6 mt-5" style="border-style: ridge; height:400px">
            <img src="" alt="">
        </div>
        <div class="details col-6 mt-5">
        <h3>Profile</h3>
        <?php
            if(isset($_SESSION['user_role'])){?>
                <form action="" method="GET">
                <label>Name:</label><br>
                <input type="text" class="form-control" name="seller_name" value="<?= ucfirst($_SESSION['user_name']) ?>">
                <label>Email:</label><br>
                <input type="text" class="form-control" name="seller_email" value="<?=$_SESSION['user_email']?>">
                <label>Contact Number:</label><br>
                <input type="text" class="form-control" name="seller_phone" value="<?=$_SESSION['user_phone']?>">
                <br>
                </form>
           <?php }  ?>
        </div>
    </div>
</div>


<div class="container">
    <div class="row">
        <div class="col histoey">
            <div class="details" style="position: relative; margin-top: 100px; text-align:center;">
                <h3>Auction Details</h3>
                <table style="width:100%">
                    <tr>
                        <th>Auction Id</th>
                        <th>Product Name</th>
                        <th>Auction Winner</th>
                        <th>Sold At</th>
                    </tr>
                    <?php
                    $result= getData($con,'auction');
                        while($row=mysqli_fetch_assoc($result)){
                            $temp= getDataWhere($con,'id',$row['product_id'],'product');
                            $product=mysqli_fetch_assoc($temp);
                            $temp_1= getDataWhere($con,'id',$row['bidder_id'],'user');
                            $bidder=mysqli_fetch_assoc($temp_1);
                            ?>
                                <tr>
                                    <td><?php echo $row['id']?></td>
                                    <td><?php echo $product['product_name']?></td>
                                    <td><?php echo $bidder['user_name']?></td>
                                    <td><?php echo $row['bid_amount']?></td>
                                </tr>
                     <?php }
                    ?>
                </table>               
            </div>                    
        </div>
    </div>
</div>


<?php
include 'admin_sign_up.php';
?>


<style>
table, th, td {
    border-style: ridge;
    border-color: #e2e3e2;
    border-width: 5px;
}
</style>

<?php
    include '../footer.php';
?>