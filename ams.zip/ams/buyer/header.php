<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Auction Management System</title>
</head>
<body>

    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="col-2">
                <a class="navbar-brand" href="../index.php">Navbar</a>
            </div>
            <div class="collapse navbar-collapse col-6" id="navbarNav">
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="../index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="#">My Dashboard</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="../include/cart.php">My Cart</a>
                </li>

                </ul>
            </div>
            <div class="col-3">
                <h6>Hello, <?= $_SESSION['user_name'] ?></h6>
            </div>
            <div class="col-3">
                <a class="nav-link" href="../sign_out.php">Sign Out</a>
            </div>
        </nav>
    </div>