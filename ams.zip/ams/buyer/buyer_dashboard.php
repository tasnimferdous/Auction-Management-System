<?php
    session_start();
    include 'header.php';
?>




<div class="container">
    <div class="row align-items-center profile">
        <div class="image col-6 mt-5" style="border-style: ridge; height:400px">
            <img src="" alt="">
        </div>
        <div class="details col-6 mt-5">
        <h3>Profile</h3>
        <?php
            if(isset($_SESSION['user_role'])){?>
                <form action="" method="GET">
                <label>Name:</label><br>
                <input type="text" class="form-control" name="seller_name" value="<?= ucfirst($_SESSION['user_name']) ?>">
                <label>Email:</label><br>
                <input type="text" class="form-control" name="seller_email" value="<?=$_SESSION['user_email']?>">
                <label>Contact Number:</label><br>
                <input type="text" class="form-control" name="seller_phone" value="<?=$_SESSION['user_phone']?>">
                <br>
                </form>
           <?php }  ?>
        </div>
    </div>
</div>


<?php
    include 'footer.php';
?>