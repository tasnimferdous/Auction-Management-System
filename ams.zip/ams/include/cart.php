<?php
session_start();
include 'header.php';
require_once('../work/function.php');
require_once('../work/db.php');




?>


<div class="container">
    <div class="row">
        <div class="col cart">
            <div class="details" style="position: relative; margin-top: 100px; text-align:center;">
                <h5>My Shopping Details</h5>
                <table style="width:100%">
                    <tr>
                        <th>Auction Id</th>
                        <th>Product Name</th>
                        <th>Bid Amount</th>
                    </tr>
                    <?php
                    $result= getDataWhere($con,'bidder_id',$_SESSION['user_id'],'auction');
                    $total=0;
                    if($result){?>
                        <form method="post" action="">
                        <?php 
                        while($row=mysqli_fetch_assoc($result)){
                            $temp= getDataWhere($con,'id',$row['product_id'],'product');
                            $product=mysqli_fetch_assoc($temp);
                            ?>
                                <tr>
                                    <td><?php echo $row['id']?></td>
                                    <td><?php echo $product['product_name']?></td>
                                    <td><?php echo $row['bid_amount']?></td>
                                </tr>
                        <?php
                            $total=$total+$row['bid_amount'];
                        }?>
                        <input type="hidden" class="form-control" name="customer_id" value="<?= $_SESSION['user_id'] ?>">
                        <input type="hidden" class="form-control" name="total_amount" value="<?= $total ?>">

                        </form>
                    <?php } else{?>
                        <h5>No Item In The Cart</h5>
                    <?php }
                    ?>
                </table>               
            </div> 
            <div class="total" style="text-align:right; margin: 10px 0;">
                <h5>Total amount <?=$total?> BDT</h5>
            </div>                     
        </div>
    </div>
</div>

<style>
table, th, td {
    border-style: ridge;
    border-color: #e2e3e2;
    border-width: 5px;
}
</style>

<?php

include '../footer.php';
?>