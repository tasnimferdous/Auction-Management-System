<?php
session_start();
if(isset($_POST['place_bid']) && $_SESSION['user_role']=='bidder'){
    require_once('../work/db.php');
    require_once('../work/function.php');
    
    $bidder_id=$_POST['bidder_id'];
    $product_id=$_POST['product_id'];
    $product_price=$_POST['product_price'];
    $bid_amount=$_POST['bid_amount'];

    placeBid($con,$product_id,$product_price,$bidder_id,$bid_amount);
    
}else{
    echo"<script>alert ('Sign in as a bidder');
            window.location.href='../sign_in.php';
        </script>";
}

?>