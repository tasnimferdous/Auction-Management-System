<?php
session_start();
include 'header.php';






if(isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on')  {
    $url = "https://";   
}
else {
    $url = "http://";   
}
  
$url.= $_SERVER['HTTP_HOST'];   
 
$url.= $_SERVER['REQUEST_URI'];   

$url_components = parse_url($url);


if(sizeof($url_components)>3){

 
    if(isset($_GET['value']) || isset($_GET['value2'])){
        if(isset($_GET['value1']) && isset($_GET['value2'])){
            echo"<script>alert ('Bid more than the current value');
            </script>";
        }else{
            echo"<script>alert ('Congrats!! Your bid placed successfully');
            </script>";
        }
    }
      
   
}










if(isset($_POST['view_product']) || isset($_GET['value']) || isset($_GET['value2']) ){
    require_once('../work/db.php');
    require_once('../work/function.php');
    if(isset($_POST['view_product'])){
        $product_id = $_POST['product_id'];
    }else{
        if(isset($_GET['value2'])){
            $product_id = $_GET['value2'];
        }else{
            $product_id = $_GET['value'];
        }
    }
    

    $result= getDataWhere($con,'id',$product_id,'product');
    $row=mysqli_fetch_assoc($result);

    $auction_data=getData($con,'auction');
    $check_in_array=array();
    while($check=mysqli_fetch_assoc($auction_data)){
        array_push($check_in_array,$check['product_id']);
    }

    if(in_array($product_id,$check_in_array)){
        $bid_result= getDataWhere($con,'product_id',$product_id,'auction');
        $highest_bid=mysqli_fetch_assoc($bid_result);
    }

?>

<div class="container">
    <div class="row">
        <div class="col-6 mb-5" >
            <div class="card h-100">
                <!-- Product image-->
                <img class="card-img-top" style="height: 400px; width:300px;" src="../image/<?= $row['product_img'] ?>" alt="..." />
                <!-- Product details-->
                <div class="card-body p-4">
                    <div class="text-center">
                        <!-- Product name-->
                        <h5 class="fw-bolder"><?= $row['product_name'] ?></h5>
                                            
                        <!-- Product price-->
                        <p><?= $row['product_price'] ?> BDT</p>
                    </div>
                </div>
                <!-- Product actions-->
                <div class="card-footer p-4 pt-0 border-top-0 bg-transparent">
                    <div class="text-center"><a class="btn btn-outline-dark mt-auto" href="#">View</a></div>
                </div>
            </div>
        </div>
        <div class="col-6">
            <div class="bid_title" style="position: relative; margin-top: 250px;">
                <h5>Place your bid here</h5>
                <p>You must bid more than the current price of the product</p>
            </div>
            <div class="bid_form mt-5">
                <form action="place_bid.php" method="post">
                    <?php
                    if(isset($_SESSION['user_role'])){
                        if($_SESSION['user_role']=='bidder'){?>
                            <input type="hidden" class="" name="bidder_id" value="<?= $_SESSION['user_id'] ?>"><br><br>
                        <?php }
                    }
                    ?>
                    <input type="hidden" class="" name="product_id" value="<?= $row['id'] ?>"><br><br>
                    <?php
                    if(isset($_GET['last_bid'])){?>
                        <label>Current value 1</label><br>
                        <input type="text" class="" name="product_price" value="<?= $_GET['last_bid'] ?>"><br><br>
                    
                    <?php }elseif(in_array($product_id,$check_in_array)){?>
                        <label>Current value 2</label><br>
                        <input type="text" class="" name="product_price" value="<?= $highest_bid['bid_amount'] ?>"><br><br>
                    <?php }else{?>
                        <label>Current value 3</label><br>
                        <input type="text" class="" name="product_price" value="<?= $row['product_price'] ?>"><br><br>
                   <?php }
                    ?>
                    <label>Enter amount</label><br>
                    <input type="text" class="" name="bid_amount"><br><br>
                    <input type="submit"  value="Place Bid" class="btn btn-small btn-info" name="place_bid">
                </form>
            </div>
        </div>
    </div>
</div>

<?php 
} ?>

<?php

include '../footer.php';
?>