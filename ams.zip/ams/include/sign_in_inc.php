<?php
session_start();
if(isset($_POST['user_signin'])){
    require_once('../work/db.php');
    require_once('../work/function.php');
    $user_email = $_POST['user_email'];
    $user_password = md5($_POST['user_password']);
    signInUser($con,$user_email, $user_password);
}


?>