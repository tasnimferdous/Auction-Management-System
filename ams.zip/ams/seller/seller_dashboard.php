<?php
    session_start();
    include 'header.php';

?>


<div class="container">
    <div class="row align-items-center profile">
        <div class="image col-6 mt-5" style="border-style: ridge; height:400px">
            <img src="" alt="">
        </div>
        <div class="details col-6 mt-5">
        <h3>Profile</h3>
        <?php
            if(isset($_SESSION['user_role'])){?>
                <form action="" method="GET">
                <label>Name:</label><br>
                <input type="text" class="form-control" name="seller_name" value="<?= ucfirst($_SESSION['user_name']) ?>">
                <label>Email:</label><br>
                <input type="text" class="form-control" name="seller_email" value="<?=$_SESSION['user_email']?>">
                <label>Contact Number:</label><br>
                <input type="text" class="form-control" name="seller_phone" value="<?=$_SESSION['user_phone']?>">
                <br>
                </form>
           <?php }  ?>
        </div>
    </div>
</div>

<div class="container">
    <div class="row align-items-center">
        <div class="product_upload col-6 mt-5">
        <h3>Create A New Auction</h3>
            <?php
            if(isset($_GET['image_error'])){
                print_r($_GET['image_error']);
            }
            ?>
            <form action="insert_product.php" method="POST" enctype="multipart/form-data">
                <label>Enter Product Name:</label><br>
                <input type="text" class="form-control" name="product_name">
                <label>Enter Starting Price:</label><br>
                <input type="text" class="form-control" name="product_price">
                <label>Upload image</label>
                <input type="file" class="form-control" name="product_image">
                <label>Select bid starting time</label>
                <input type="datetime-local" class="form-control" name="start_time">
                <label>Select bid ending time</label>
                <input type="datetime-local" class="form-control" name="end_time">
                <br>
                <input type="submit"  value="Submit" class="btn btn-small btn-info" name="create_auction">
            </form>
        </div>
    </div>
</div>



<?php
    include '../footer.php';
?>