<?php

require_once('../work/function.php');

if(isset($_POST['create_auction']) && isset($_FILES['product_image'])){
    require_once("../work/db.php");
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $start_time = $_POST['start_time'];
    $end_time = $_POST['end_time'];
    $product_image = $_FILES['product_image']['name'];
    $image_tmp = $_FILES['product_image']['tmp_name'];
    $image_size = $_FILES['product_image']['size'];
    $image_error = $_FILES['product_image']['error'];
    insertIntoProduct($con,$product_name,$product_price,$product_image,$image_tmp,$image_size,$image_error,$start_time,$end_time);

}

?>