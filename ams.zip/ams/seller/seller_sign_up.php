<?php
require_once('../work/function.php');

if(isset($_POST['seller_signup'])){
    
    require_once('../work/db.php');
    $user_name = $_POST['seller_name'];
    $user_email = $_POST['seller_email'];
    $user_phone = $_POST['seller_phone'];
    $user_password = md5($_POST['seller_password']);
    $user_password_confirm = md5($_POST['seller_password_confirm']);
    $user_role = "seller";
    
    if($user_password == $user_password_confirm){
        $sql="SELECT * FROM user WHERE user_email='$user_email'";
        $result=mysqli_query($con,$sql);
        if(mysqli_num_rows($result)>0){
            echo"<script>alert ('Email already exists');
            window.location.href='../sign_up.php';
            </script>";
        }
        else{
            signUpUser($con, $user_name, $user_email, $user_phone, $user_password, $user_role);
        }
    }else{
        echo"<script>alert ('Password doesn\'t match');
        window.location.href='../sign_up.php';
        </script>";
    }
}


?>