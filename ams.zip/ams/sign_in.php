<?php
    include 'header.php';
?>



<div class="container">

    <div class="row align-items-center">
        <div class="col-4"></div>
        <div class="user_signin col-4 mt-5">
        <h3>Sign in</h3>
            <form action="include/sign_in_inc.php" method="POST">
                <label>Enter Email:</label><br>
                <input type="email" class="form-control" name="user_email" required>
                <label>Enter Password:</label><br>
                <input type="password" class="form-control" name="user_password" required><br>

                <input type="submit"  value="Sign In" class="btn btn-small btn-info" name="user_signin">
            </form>
        </div>
        <div class="col-4"></div>

        <div class="mt-5">
            <h5 class="text-center">Don't have an account? <a href="sign_up.php">Sign up</a></h5>
        </div>
    </div>

</div>


<?php
    include 'footer.php';
?>