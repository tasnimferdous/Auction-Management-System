<?php
    include 'header.php';

?>


<div class="container">

    <div class="row align-items-center">
        <div class="col mt-5">
            <br><br>
            <h3>Sign up as a seller</h3>
            <div class="seller-signup" >
                <form action="seller/seller_sign_up.php" method="POST">
                    <label>Enter Name:</label><br>
                    <input type="text" class="form-control" name="seller_name" required>
                    <label>Enter Email:</label><br>
                    <input type="email" class="form-control" name="seller_email" required>
                    <label>Enter Contact Number:</label><br>
                    <input type="tel" class="form-control" name="seller_phone" required>
                    <label>Enter Password:</label><br>
                    <input type="password" class="form-control" name="seller_password" required>
                    <label>Confirm Password:</label><br>
                    <input type="password" class="form-control" name="seller_password_confirm" required>
                    <br>

                    <input type="submit" value="Sign Up" class="btn btn-small btn-info" name="seller_signup"><br>
                </form>
            </div>

        </div>
        <div class="col mt-5">
            <br><br>
            <h3>Sign up as a bidder</h3>
            <div class="bidder-signup">
                <form action="buyer/buyer_sign_up.php" method="POST">
                    <label>Enter Name:</label><br>
                    <input type="text" class="form-control" name="bidder_name" required> 
                    <label>Enter Email:</label><br>
                    <input type="text" class="form-control" name="bidder_email" required>
                    <label>Enter Contact Number:</label><br>
                    <input type="tel" class="form-control" name="bidder_phone" required>
                    <label>Enter Password:</label><br>
                    <input type="password" class="form-control" name="bidder_password" required>
                    <label>Confirm Password:</label><br>
                    <input type="password" class="form-control" name="bidder_password_confirm" required>
                    <br>
                    <input type="submit"  value="Sign Up" class="btn btn-small btn-info" name="bidder_signup">
                </form>
            </div>
        </div>

        <div class="mt-5">
            <h5 class="text-center">Already have an account? <a href="sign_in.php">Sign In</a></h5>
        </div>
    </div>

</div>


<?php
    include 'footer.php';
?>