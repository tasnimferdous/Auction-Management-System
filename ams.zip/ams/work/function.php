<?php


//Insert Product and create auction
function insertIntoProduct($con,$product_name,$product_price,$product_image,$image_tmp,$image_size,$image_error,$start_time,$end_time){

    

    if($image_error===0){
        if($image_size>500000){
            echo"<script>alert ('File size is too large');
                    window.location.href='seller_dashboard.php';
            </script>";
        }else{
            $image_exn = strtolower(pathinfo($product_image,PATHINFO_EXTENSION));
            $allowed_exn = array("jpg","jpeg","png");
            if(in_array($image_exn,$allowed_exn)){
                $img_new_name = uniqid("IMG-",true).'.'.$image_exn;
                $img_upload_path = '../image/'.$img_new_name;
                move_uploaded_file($image_tmp,$img_upload_path);
                $sql = "INSERT INTO product (product_name, product_price,product_img,start_time,end_time) VALUES
                 ('$product_name', '$product_price', '$img_new_name', '$start_time', '$end_time')";

                mysqli_query($con, $sql);
                header('Location: ../index.php');

            }else{
                echo"<script>alert ('This type of file is not allowed');
                    window.location.href='seller_dashboard.php';
                </script>";
            }
        }
    }else{
        echo"<script>alert ('Unknown error occured');
            window.location.href='seller_dashboard.php';
        </script>";
    }

}


//get data from a table of database
function getData($con,$tableName){
    $sql = "SELECT * FROM $tableName";
    $result = mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        return $result;
    }else{
        echo "No data available";
    }
}


//User Sign Up
function signUpUser($con, $user_name, $user_email, $user_phone, $user_password, $user_role){
    $sql = "INSERT INTO user (user_name, user_email, user_phone, user_password, user_role) VALUES
        ('$user_name', '$user_email', '$user_phone', '$user_password', '$user_role')";
    $result = mysqli_query($con, $sql);
     if($result){
         if($user_role=="admin"){
            echo"<script>alert ('Admin registration complete');
            window.location.href='dashboard.php';
            </script>";
         }else{
            echo"<script>alert ('User registration complete');
            window.location.href='../sign_in.php';
            </script>";
         }
     }else{
        echo"<script>alert ('Something went wrong');
            window.location.href='sign_up.php';
        </script>";
     }
}



function signInUser($con,$user_email, $user_password){
    $sql = "SELECT * FROM user WHERE user_email='$user_email' AND user_password='$user_password'";
    $result = mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        $row=mysqli_fetch_assoc($result);
        $_SESSION['user_id']=$row['id'];
        $_SESSION['user_name']=$row['user_name'];
        $_SESSION['user_role']=$row['user_role'];
        $_SESSION['user_email']=$row['user_email'];
        $_SESSION['user_phone']=$row['user_phone'];

        if($row['user_role']===''){
            echo"<script>alert ('No user found');
            window.location.href='../sign_in.php';
            </script>";
        }else{
            echo"<script>
            window.location.href='../index.php';
            </script>";
        }
    }else{
        echo"<script>alert ('Email or Password is incorrect');
            window.location.href='../sign_in.php';
        </script>";
    }
}

//get product data

function getDataWhere($con,$column_name,$product_id,$tableName){
    $sql = "SELECT * FROM $tableName WHERE $column_name=$product_id";
    $result = mysqli_query($con,$sql);
    if(mysqli_num_rows($result)>0){
        return $result;
    }else{
        return 0;
    }
}


//Place bid function

function placeBid($con,$product_id,$product_price,$bidder_id,$bid_amount){
    $result= getDataWhere($con,'product_id',$product_id,'auction');
    if(mysqli_num_rows($result)==0){
        $current_price=$product_price;
        if($bid_amount>$current_price){
            $sql = "INSERT INTO auction (product_id,bidder_id, bid_amount) VALUES
            ('$product_id','$bidder_id', '$bid_amount')";
            mysqli_query($con,$sql);
            header("Location:../include/auction.php?value=$product_id & last_bid=$bid_amount");
        }else{
            header("Location:../include/auction.php?value1=message & value2=$product_id & last_bid=$current_price");
        }
    }else{
        $row=mysqli_fetch_assoc($result);
        $current_price=$row['bid_amount'];
        if($bid_amount>$current_price){
            $sql="UPDATE auction SET bid_amount=$bid_amount, bidder_id=$bidder_id WHERE product_id=$product_id ";
            mysqli_query($con,$sql);
            $_SESSION['current_price']=$bid_amount;
            header("Location:../include/auction.php?value=$product_id & last_bid=$bid_amount");
        }else{
            header("Location:../include/auction.php?value1=message & value2=$product_id & last_bid=$current_price");
        }
    }
}







?>