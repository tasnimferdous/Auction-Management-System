<?php

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Auction Management System</title>
</head>
<body>

    <div class="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <div class="col-2">
                <a class="navbar-brand" href="#">Navbar</a>
            </div>
            <div class="collapse navbar-collapse col-6" id="navbarNav" style="color:aqua;">
                <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" href="">Home</a>
                </li>
                <li class="nav-item">
                    <?php 
                    if(isset($_SESSION['user_role'])){
                        if(($_SESSION['user_role'])=="seller"){ 
                            echo '<a class="nav-link" href="seller/seller_dashboard.php">My Dashboard</a>';
                        }elseif(($_SESSION['user_role'])=="bidder"){
                            echo '<a class="nav-link" href="buyer/buyer_dashboard.php">My Dashboard</a>';
                        }else{
                            echo '<a class="nav-link" href="admin/dashboard.php">Dashboard</a>';
                        }
                    }else{
                        echo '<a class="nav-link" href="">Active-Auctions</a>';
                    }
                    ?>
                </li>
                <?php
                if(isset($_SESSION['user_role'])){
                    if($_SESSION['user_role']=="bidder"){?>
                        <li class="nav-item">
                        <a class="nav-link" href="include/cart.php">My Cart</a>
                        </li>
                        <?php  }
                     }else{?>
                    <li class="nav-item">
                        <a class="nav-link" href="#">About-AMS</a>
                    </li>
                <?php } ?>
                
                </ul>
            </div>

            <div class="col-6 d-flex" style="color:aqua;">
                <?php
                if(isset($_SESSION['user_name'])){?>
                    <h6 style="margin:0;line-height:2.5;">hello, <?= $_SESSION['user_name'] ?></h6>
                <?php }
                if(isset($_SESSION['user_role'])){
                    echo'<a class="nav-link" href="sign_out.php">Sign Out</a>';
                }else{
                    echo'<a class="nav-link" href="sign_in.php">Sign In</a>';
                }
                ?>
            </div>
        </nav>
    </div>